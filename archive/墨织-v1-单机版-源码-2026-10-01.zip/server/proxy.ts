/**
 * 本地模型代理：浏览器 → 本机 Node → 模型服务商。
 *
 * 为什么需要它：多数模型 API 不允许浏览器跨域直连（CORS），而且直连会把
 * API Key 暴露在浏览器网络面板里。代理只在本机运行（默认绑定 127.0.0.1），
 * 只转发 POST 请求与一小组白名单请求头，并原样流式回传响应体（SSE）。
 *
 * 安全边界：该代理会把请求转发到浏览器指定的 URL，只适合在本机使用。
 * 不要把它部署到公网，否则会成为开放代理（SSRF 风险）。
 */
import type { IncomingMessage, ServerResponse } from 'node:http';
import { Readable } from 'node:stream';
import { pipeline } from 'node:stream/promises';

const FORWARD_HEADERS = ['authorization', 'x-api-key', 'anthropic-version', 'content-type', 'accept', 'http-referer', 'x-title'];
const MAX_BODY_BYTES = 4 * 1024 * 1024;

function readBody(req: IncomingMessage): Promise<Buffer> {
  return new Promise((resolve, reject) => {
    const chunks: Buffer[] = [];
    let size = 0;
    req.on('data', (chunk: Buffer) => {
      size += chunk.length;
      if (size > MAX_BODY_BYTES) {
        reject(new Error('请求体过大'));
        req.destroy();
        return;
      }
      chunks.push(chunk);
    });
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}

function fail(res: ServerResponse, status: number, message: string) {
  if (res.headersSent) return res.end();
  res.statusCode = status;
  res.setHeader('content-type', 'application/json; charset=utf-8');
  res.end(JSON.stringify({ error: { message } }));
}

/** 处理 /api/proxy 请求；返回 true 表示已处理。 */
export async function handleProxy(req: IncomingMessage, res: ServerResponse): Promise<boolean> {
  if (!req.url?.startsWith('/api/proxy')) return false;

  if (req.method !== 'POST') {
    fail(res, 405, '仅支持 POST');
    return true;
  }

  const target = String(req.headers['x-target-url'] ?? '');
  let url: URL;
  try {
    url = new URL(target);
  } catch {
    fail(res, 400, '缺少或无效的 x-target-url');
    return true;
  }
  if (url.protocol !== 'https:' && url.protocol !== 'http:') {
    fail(res, 400, '只允许 http/https 目标');
    return true;
  }

  const headers: Record<string, string> = {};
  for (const name of FORWARD_HEADERS) {
    const value = req.headers[name];
    if (typeof value === 'string' && value) headers[name] = value;
  }

  const controller = new AbortController();
  // 浏览器取消（停止生成）时，同步取消上游请求，避免继续计费。
  res.on('close', () => {
    if (!res.writableFinished) controller.abort();
  });

  // 浏览器到代理始终是 POST；转发到上游时可以是 GET（用于探测协议、获取模型列表）
  const method = String(req.headers['x-target-method'] ?? 'POST').toUpperCase();
  if (method !== 'POST' && method !== 'GET') {
    fail(res, 400, '只允许转发 GET / POST');
    return true;
  }

  try {
    const body = await readBody(req);
    const upstream = await fetch(url, {
      method,
      headers,
      body: method === 'GET' ? undefined : new Uint8Array(body),
      signal: controller.signal,
    });

    res.statusCode = upstream.status;
    const contentType = upstream.headers.get('content-type');
    if (contentType) res.setHeader('content-type', contentType);
    res.setHeader('cache-control', 'no-cache');
    res.setHeader('x-accel-buffering', 'no');

    if (!upstream.body) {
      res.end();
      return true;
    }
    // pipeline 会处理两端的错误与提前关闭（例如用户点了“停止”），不会让未捕获的 AbortError 打崩服务
    await pipeline(Readable.fromWeb(upstream.body as import('node:stream/web').ReadableStream), res).catch((error) => {
      if (!controller.signal.aborted) console.warn('[proxy] 流式转发中断：', error instanceof Error ? error.message : error);
    });
  } catch (error) {
    if (controller.signal.aborted) return true;
    const message = error instanceof Error ? error.message : String(error);
    fail(res, 502, `无法连接模型服务：${message}`);
  }
  return true;
}
