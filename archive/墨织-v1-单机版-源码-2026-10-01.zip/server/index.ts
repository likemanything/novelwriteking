/**
 * 生产模式服务器：托管 dist/ 静态资源 + /api/proxy 模型代理。
 * 用法：npm run build && npm start   （默认 http://127.0.0.1:4318）
 */
import { createServer } from 'node:http';
import { createReadStream, existsSync, statSync } from 'node:fs';
import { extname, join, normalize, resolve } from 'node:path';
import { handleProxy } from './proxy.ts';

const HOST = process.env.HOST ?? '127.0.0.1';
const PORT = Number(process.env.PORT ?? 4318);
const DIST = resolve(import.meta.dirname, '..', 'dist');

const MIME: Record<string, string> = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.ico': 'image/x-icon',
  '.json': 'application/json',
  '.woff': 'font/woff',
  '.woff2': 'font/woff2',
};

if (!existsSync(DIST)) {
  console.error('未找到 dist/，请先运行 npm run build');
  process.exit(1);
}

const server = createServer(async (req, res) => {
  if (await handleProxy(req, res)) return;

  const pathname = decodeURIComponent(new URL(req.url ?? '/', 'http://x').pathname);
  // 防止路径穿越：规范化后必须仍在 dist 目录内。
  let file = normalize(join(DIST, pathname));
  if (!file.startsWith(DIST)) {
    res.statusCode = 403;
    return res.end();
  }
  if (!existsSync(file) || statSync(file).isDirectory()) {
    file = join(DIST, 'index.html'); // SPA 回退
  }
  const ext = extname(file);
  res.setHeader('content-type', MIME[ext] ?? 'application/octet-stream');
  if (file.includes(`${join(DIST, 'assets')}`)) {
    res.setHeader('cache-control', 'public, max-age=31536000, immutable');
  }
  createReadStream(file).pipe(res);
});

server.listen(PORT, HOST, () => {
  console.log(`墨织 Inkloom 已启动 → http://${HOST}:${PORT}`);
});
