import { defineConfig, type Plugin } from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';
import { fileURLToPath } from 'node:url';
import { handleProxy } from './server/proxy.ts';

/** 在 dev / preview 服务器中挂载本地模型代理，与生产服务器共用同一套逻辑。 */
function modelProxy(): Plugin {
  const mount = (middlewares: { use: (fn: (req: any, res: any, next: () => void) => void) => void }) =>
    middlewares.use((req, res, next) => {
      handleProxy(req, res).then((handled) => {
        if (!handled) next();
      });
    });
  return {
    name: 'inkloom-model-proxy',
    configureServer(server) {
      mount(server.middlewares);
    },
    configurePreviewServer(server) {
      mount(server.middlewares);
    },
  };
}

export default defineConfig({
  plugins: [react(), tailwindcss(), modelProxy()],
  resolve: {
    alias: { '@': fileURLToPath(new URL('./src', import.meta.url)) },
  },
  server: { host: '127.0.0.1', port: 5173 },
  preview: { host: '127.0.0.1', port: 4173 },
});
