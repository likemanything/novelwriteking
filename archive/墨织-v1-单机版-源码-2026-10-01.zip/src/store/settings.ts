import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { uid } from '@/lib/util';

export type ProviderKind = 'openai' | 'anthropic' | 'demo';
export type Stage = 'plan' | 'write' | 'review' | 'muse';

export const STAGE_LABEL: Record<Stage, { label: string; hint: string }> = {
  plan: { label: '构思', hint: '开书、大纲、提炼' },
  write: { label: '写作', hint: '章节草稿与修订' },
  review: { label: '审稿', hint: '结构化审稿报告' },
  muse: { label: '改写', hint: '划词改写、续写、角色访谈' },
};

export interface ModelProfile {
  id: string;
  name: string;
  provider: ProviderKind;
  baseUrl: string;
  apiKey: string;
  model: string;
  temperature: number;
  maxTokens: number;
  useProxy: boolean;
  /** 自动识别时读到的模型列表，供切换模型 */
  models?: string[];
  /** 自动识别得到的协议说明，例如「OpenAI 兼容」 */
  protocolLabel?: string;
}

/** DeepSeek 一键接入：OpenAI 兼容协议，只需要 Key。模型名以接口返回的列表为准。 */
export const DEEPSEEK_URL = 'https://api.deepseek.com';

/** 通用接入的常见地址示例（只是填入地址，协议仍由自动识别决定）。 */
export const URL_EXAMPLES: { label: string; url: string }[] = [
  { label: 'OpenAI', url: 'https://api.openai.com/v1' },
  { label: 'Claude', url: 'https://api.anthropic.com' },
  { label: '通义千问', url: 'https://dashscope.aliyuncs.com/compatible-mode/v1' },
  { label: 'Kimi', url: 'https://api.moonshot.cn/v1' },
  { label: '智谱', url: 'https://open.bigmodel.cn/api/paas/v4' },
  { label: 'OpenRouter', url: 'https://openrouter.ai/api/v1' },
  { label: 'Ollama 本地', url: 'http://127.0.0.1:11434' },
];

export const DEMO_PROFILE: ModelProfile = {
  id: 'demo',
  name: '演示引擎（离线）',
  provider: 'demo',
  baseUrl: '',
  apiKey: '',
  model: 'inkloom-demo',
  temperature: 0.8,
  maxTokens: 4096,
  useProxy: false,
};

interface SettingsState {
  theme: 'paper' | 'night' | 'system';
  profiles: ModelProfile[];
  stages: Record<Stage, string>;
  contextBudget: number;
  editorSize: number;
  typewriter: boolean;
  reducedMotion: boolean;
  onboarded: boolean;
  setTheme: (t: SettingsState['theme']) => void;
  upsertProfile: (p: ModelProfile) => void;
  removeProfile: (id: string) => void;
  setStage: (s: Stage, profileId: string) => void;
  patch: (p: Partial<Pick<SettingsState, 'contextBudget' | 'editorSize' | 'typewriter' | 'reducedMotion' | 'onboarded'>>) => void;
}

export const useSettings = create<SettingsState>()(
  persist(
    (set) => ({
      theme: 'system',
      profiles: [],
      stages: { plan: 'demo', write: 'demo', review: 'demo', muse: 'demo' },
      contextBudget: 12000,
      editorSize: 18,
      typewriter: false,
      reducedMotion: false,
      onboarded: false,
      setTheme: (theme) => set({ theme }),
      upsertProfile: (p) =>
        set((s) => {
          const exists = s.profiles.some((x) => x.id === p.id);
          const profiles = exists ? s.profiles.map((x) => (x.id === p.id ? p : x)) : [...s.profiles, p];
          // 第一个真实模型自动接管全部环节，省去一步配置
          const stages = !exists && s.profiles.length === 0 ? { plan: p.id, write: p.id, review: p.id, muse: p.id } : s.stages;
          return { profiles, stages };
        }),
      removeProfile: (id) =>
        set((s) => ({
          profiles: s.profiles.filter((p) => p.id !== id),
          stages: Object.fromEntries(Object.entries(s.stages).map(([k, v]) => [k, v === id ? 'demo' : v])) as Record<Stage, string>,
        })),
      setStage: (stage, profileId) => set((s) => ({ stages: { ...s.stages, [stage]: profileId } })),
      patch: (p) => set(p),
    }),
    { name: 'inkloom.settings', version: 1 },
  ),
);

export function newProfile(init: Partial<ModelProfile> = {}): ModelProfile {
  return {
    id: uid('m_'),
    name: '自定义模型',
    provider: 'openai',
    baseUrl: '',
    apiKey: '',
    model: '',
    temperature: 0.85,
    maxTokens: 4096,
    useProxy: true,
    ...init,
  };
}

export function profileFor(stage: Stage): ModelProfile {
  const s = useSettings.getState();
  return s.profiles.find((p) => p.id === s.stages[stage]) ?? DEMO_PROFILE;
}
