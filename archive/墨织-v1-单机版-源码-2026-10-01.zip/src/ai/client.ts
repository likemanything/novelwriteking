/**
 * 统一的流式对话客户端。
 *
 * - openai：任何兼容 Chat Completions 的服务（DeepSeek、通义、Kimi、OpenRouter、Ollama…）
 * - anthropic：Claude Messages API
 * - demo：离线演示引擎，按“打字”节奏回放本地生成的内容，让没有 API Key 的人也能完整体验
 *
 * 默认经由本机 /api/proxy 转发，避免浏览器跨域限制，也不把 Key 暴露给第三方页面脚本。
 */
import type { ModelProfile } from '@/store/settings';
import { sleep } from '@/lib/util';

export interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
}

export interface StreamOptions {
  profile: ModelProfile;
  system: string;
  messages: ChatMessage[];
  /** 离线演示引擎的输出（仅在 provider=demo 时调用） */
  demo: () => string;
  signal?: AbortSignal;
  onToken?: (chunk: string, full: string) => void;
  temperature?: number;
  maxTokens?: number;
}

export class AIError extends Error {
  constructor(message: string, public status?: number) {
    super(message);
    this.name = 'AIError';
  }
}

export async function streamChat(o: StreamOptions): Promise<string> {
  if (o.profile.provider === 'demo') return playDemo(o);
  const res = await send(o);
  if (!res.ok) throw await toError(res, o.profile);
  const type = res.headers.get('content-type') ?? '';
  // 部分服务在不支持流式时会直接返回 JSON
  if (!type.includes('event-stream') && type.includes('json')) {
    const data = await res.json();
    const text = o.profile.provider === 'anthropic'
      ? (data.content ?? []).map((b: { text?: string }) => b.text ?? '').join('')
      : data.choices?.[0]?.message?.content ?? '';
    o.onToken?.(text, text);
    return text;
  }
  return readSSE(res, o);
}

function joinUrl(base: string, path: string) {
  return base.replace(/\/+$/, '') + path;
}

async function send(o: StreamOptions): Promise<Response> {
  const p = o.profile;
  const temperature = o.temperature ?? p.temperature;
  const max_tokens = o.maxTokens ?? p.maxTokens;
  let url: string;
  let headers: Record<string, string>;
  let body: unknown;

  if (p.provider === 'anthropic') {
    const base = p.baseUrl.replace(/\/v1\/?$/, '');
    url = joinUrl(base, '/v1/messages');
    headers = { 'content-type': 'application/json', 'x-api-key': p.apiKey, 'anthropic-version': '2023-06-01' };
    if (!p.useProxy) headers['anthropic-dangerous-direct-browser-access'] = 'true';
    body = { model: p.model, system: o.system, messages: o.messages, max_tokens, temperature, stream: true };
  } else {
    url = joinUrl(p.baseUrl, '/chat/completions');
    headers = { 'content-type': 'application/json', accept: 'text/event-stream' };
    if (p.apiKey) headers.authorization = `Bearer ${p.apiKey}`;
    body = {
      model: p.model,
      messages: [{ role: 'system', content: o.system }, ...o.messages],
      temperature,
      max_tokens,
      stream: true,
    };
  }

  return rawRequest({ url, method: 'POST', headers, body: JSON.stringify(body), useProxy: p.useProxy, signal: o.signal });
}

/**
 * 底层请求：经本地代理（默认）或浏览器直连。
 * 网络层失败统一转为可读的 AIError；中断（AbortError）原样抛出。
 */
export async function rawRequest(o: { url: string; method: 'GET' | 'POST'; headers: Record<string, string>; body?: string; useProxy: boolean; signal?: AbortSignal }): Promise<Response> {
  try {
    if (o.useProxy) {
      return await fetch('/api/proxy', {
        method: 'POST',
        headers: { ...o.headers, 'x-target-url': o.url, 'x-target-method': o.method },
        body: o.body ?? '',
        signal: o.signal,
      });
    }
    return await fetch(o.url, { method: o.method, headers: o.headers, body: o.method === 'GET' ? undefined : o.body, signal: o.signal });
  } catch (error) {
    if (o.signal?.aborted) throw error;
    throw new AIError(
      o.useProxy
        ? '无法连接本地代理。请用 npm run dev 或 npm start 启动墨织。'
        : '无法直连模型服务：可能是跨域限制或网络问题。可在模型设置中开启「经本地代理」。',
    );
  }
}

async function toError(res: Response, p: ModelProfile): Promise<AIError> {
  let detail = '';
  try {
    const raw = await res.text();
    try {
      const j = JSON.parse(raw);
      detail = j.error?.message ?? j.message ?? raw;
    } catch {
      detail = raw;
    }
  } catch {
    /* ignore */
  }
  detail = String(detail).slice(0, 240);
  if (res.status === 404 && p.useProxy && !detail) return new AIError('本地代理不可用：请通过 npm run dev 或 npm start 运行墨织。', 404);
  const hint: Record<number, string> = {
    400: '请求被拒绝，检查模型名与参数',
    401: 'API Key 无效或缺失',
    403: '没有访问该模型的权限',
    404: '接口地址或模型名不正确',
    429: '请求过于频繁或额度不足',
    500: '模型服务内部错误',
    502: '模型服务暂不可用',
    503: '模型服务繁忙',
  };
  return new AIError(`${hint[res.status] ?? `请求失败（${res.status}）`}${detail ? `：${detail}` : ''}`, res.status);
}

async function readSSE(res: Response, o: StreamOptions): Promise<string> {
  if (!res.body) throw new AIError('模型没有返回内容');
  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buffer = '';
  let full = '';
  const anthropic = o.profile.provider === 'anthropic';

  const handle = (line: string) => {
    const trimmed = line.trim();
    if (!trimmed.startsWith('data:')) return;
    const data = trimmed.slice(5).trim();
    if (!data || data === '[DONE]') return;
    let json: any;
    try {
      json = JSON.parse(data);
    } catch {
      return;
    }
    if (json.error) throw new AIError(json.error.message ?? '模型返回错误');
    const chunk: string = anthropic
      ? json.type === 'content_block_delta' ? json.delta?.text ?? '' : ''
      : json.choices?.[0]?.delta?.content ?? '';
    if (chunk) {
      full += chunk;
      o.onToken?.(chunk, full);
    }
  };

  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });
    const lines = buffer.split('\n');
    buffer = lines.pop() ?? '';
    for (const line of lines) handle(line);
  }
  if (buffer) handle(buffer);
  if (!full.trim()) throw new AIError('模型返回了空内容');
  return full;
}

/** 以接近真实模型的节奏回放演示内容。 */
async function playDemo(o: StreamOptions): Promise<string> {
  const text = o.demo();
  await sleep(380, o.signal); // 模拟首字延迟
  const ticks = Math.min(420, Math.max(40, Math.round(text.length / 4)));
  const step = Math.max(1, Math.ceil(text.length / ticks));
  let full = '';
  for (let i = 0; i < text.length; i += step) {
    const chunk = text.slice(i, i + step);
    full += chunk;
    o.onToken?.(chunk, full);
    await sleep(14 + Math.random() * 10, o.signal);
  }
  return full;
}

/** 连接测试：发送一个极短请求。 */
export async function testConnection(profile: ModelProfile): Promise<string> {
  const text = await streamChat({
    profile,
    system: '你是连接测试助手。',
    messages: [{ role: 'user', content: '请只回复两个字：你好' }],
    maxTokens: 256,
    temperature: 0,
    demo: () => '你好',
  });
  return text.trim().slice(0, 40);
}
