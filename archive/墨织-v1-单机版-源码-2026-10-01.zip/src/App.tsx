import { MotionConfig } from 'motion/react';
import { lazy, Suspense, type ReactNode } from 'react';
import { BrowserRouter, Navigate, Route, Routes, useLocation } from 'react-router';
import { CommandPalette } from '@/components/CommandPalette';
import { ErrorBoundary } from '@/components/ErrorBoundary';
import { JobDock } from '@/components/JobDock';
import { ProjectShell } from '@/components/ProjectShell';
import { useThemeEffect } from '@/components/ThemeToggle';
import { Toaster } from '@/components/Toaster';
import { InkSpinner } from '@/components/ui';
import { Library } from '@/pages/Library';
import { useSettings } from '@/store/settings';

const Genesis = lazy(() => import('@/pages/Genesis'));
const Overview = lazy(() => import('@/pages/Overview'));
const Bible = lazy(() => import('@/pages/Bible'));
const Outline = lazy(() => import('@/pages/Outline'));
const Studio = lazy(() => import('@/pages/Studio'));
const Loom = lazy(() => import('@/pages/Loom'));
const Inbox = lazy(() => import('@/pages/Inbox'));
const Settings = lazy(() => import('@/pages/Settings'));

function PageLoader() {
  return (
    <div className="flex h-full items-center justify-center text-ink-3">
      <InkSpinner className="size-6" />
    </div>
  );
}

function RoutedBoundary({ children }: { children: ReactNode }) {
  const location = useLocation();
  return <ErrorBoundary resetKey={location.pathname}>{children}</ErrorBoundary>;
}

export function App() {
  useThemeEffect();
  const reduced = useSettings((s) => s.reducedMotion);
  return (
    <MotionConfig reducedMotion={reduced ? 'always' : 'user'}>
      <BrowserRouter>
        <RoutedBoundary>
        <Suspense fallback={<PageLoader />}>
          <Routes>
            <Route path="/" element={<Library />} />
            <Route path="/genesis" element={<Genesis />} />
            <Route path="/settings" element={<Settings />} />
            <Route path="/p/:projectId" element={<ProjectShell />}>
              <Route index element={<Overview />} />
              <Route path="bible" element={<Bible />} />
              <Route path="outline" element={<Outline />} />
              <Route path="write" element={<Studio />} />
              <Route path="write/:chapterId" element={<Studio />} />
              <Route path="storylines" element={<Loom />} />
              <Route path="loom" element={<Navigate to="../storylines" replace />} />
              <Route path="updates" element={<Inbox />} />
              <Route path="inbox" element={<Navigate to="../updates" replace />} />
            </Route>
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </Suspense>
        </RoutedBoundary>
        <CommandPalette />
        <Toaster />
        <JobDock />
      </BrowserRouter>
    </MotionConfig>
  );
}
