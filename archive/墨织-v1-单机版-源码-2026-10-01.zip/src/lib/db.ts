import Dexie, { type EntityTable } from 'dexie';
import type {
  Chapter,
  Character,
  Critique,
  DailyWords,
  Project,
  Proposal,
  Thread,
  Version,
  WorldEntry,
} from './types';

/** 所有作品数据都存放在浏览器本地 IndexedDB，不经过任何服务器。 */
export const db = new Dexie('inkloom') as Dexie & {
  projects: EntityTable<Project, 'id'>;
  characters: EntityTable<Character, 'id'>;
  world: EntityTable<WorldEntry, 'id'>;
  threads: EntityTable<Thread, 'id'>;
  chapters: EntityTable<Chapter, 'id'>;
  versions: EntityTable<Version, 'id'>;
  critiques: EntityTable<Critique, 'id'>;
  proposals: EntityTable<Proposal, 'id'>;
  daily: EntityTable<DailyWords, 'id'>;
};

db.version(1).stores({
  projects: 'id, updatedAt',
  characters: 'id, projectId',
  world: 'id, projectId',
  threads: 'id, projectId',
  chapters: 'id, projectId, [projectId+index]',
  versions: 'id, projectId, chapterId',
  critiques: 'id, projectId, chapterId, versionId',
  proposals: 'id, projectId, status',
  daily: 'id, projectId',
});

export const PROJECT_TABLES = ['characters', 'world', 'threads', 'chapters', 'versions', 'critiques', 'proposals', 'daily'] as const;

export async function touchProject(projectId: string) {
  await db.projects.update(projectId, { updatedAt: Date.now() });
}

export async function deleteProject(projectId: string) {
  await db.transaction('rw', [db.projects, ...PROJECT_TABLES.map((t) => db[t])], async () => {
    for (const t of PROJECT_TABLES) await db[t].where('projectId').equals(projectId).delete();
    await db.projects.delete(projectId);
  });
}

function today() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

/** 记录当日新增字数（用于写作热力与连续天数）。 */
export async function logWords(projectId: string, delta: number) {
  if (delta <= 0) return;
  const date = today();
  const id = `${projectId}:${date}`;
  const existing = await db.daily.get(id);
  if (existing) await db.daily.update(id, { words: existing.words + delta });
  else await db.daily.add({ id, projectId, date, words: delta });
}
